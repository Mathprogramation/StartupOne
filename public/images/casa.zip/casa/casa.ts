import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-casa',
  imports: [FormsModule],
  templateUrl: './casa.html',
  styleUrl: './casa.css'
})

export class Casa {
  //exemplo1
  nome: string = 'Fabrício';

  //exemplo2
  contador:number=0;
  incrementar(){this.contador++;}
  decrementar(){this.contador--;}

  //exemplo3
  name: string = "";

  //exemplo4
  mostrar = false;
  
  //exemplo5
  frutas : string[] = ['Maça', 'Banana', 'Laranja'];

  //exemplo6
  doces : string[] = ['Bala', 'Pirulito', 'Chiclete'];
  selecionada ='Pirulito';

  //exemplo7
  cor:string = 'blue';

  //exemplo8
  ativo = true;

  //Exemplo 11
  like = false
}
