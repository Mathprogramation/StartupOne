import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

class Produto {
  nome: string = "";
  quantidade: number = 0;
  valor: number = 0;
}

@Component({
  selector: 'app-exercicios',
  imports: [FormsModule], // Só se standalone, senão remover e importar no módulo
  templateUrl: './exercicios.html',
  styleUrls: ['./exercicios.css']  // corrigido para 'styleUrls'
})
export class Exercicios {
  dataAtual = new Date();

  //Exercício 1
  idade = 0;
  anoNascimento = 0;
  calculaAnoNascimento(): void {
    this.anoNascimento = this.dataAtual.getFullYear() - this.idade;
  }

  //Exercício 2
  listaProdutos : Produto[] = [];
  produtoNome = "";
  produtoQuantidade = 0;
  produtoValor = 0;
  valorTotal = 

  adicionarProduto(): void {
    const novoProduto = new Produto();

    novoProduto.nome = this.produtoNome;
    novoProduto.quantidade = this.produtoQuantidade;
    novoProduto.valor = this.produtoValor;

    this.listaProdutos.push(novoProduto);

    this.produtoNome = "";
    this.produtoValor = 0;
    this.produtoQuantidade = 0;
  }

  removerProduto(index : number): void {
    this.listaProdutos.splice(index, 1)
  }

}
